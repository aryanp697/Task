//
//  GFGTableViewCell.swift
//  GFG
//
//  Created by Aryan Asija on 29/01/22.
//

import UIKit

class GFGTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    var titleLabel = UILabel()
   
     var dateLabel = UILabel()
    
     var bgView = UIView()
    
    var imageV = LatestImageView()
    
    let titleAttributes = [NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 15),
                           NSAttributedString.Key.foregroundColor: UIColor(red: 0.4414, green: 0.53125, blue: 0.4023, alpha: 1)]
    
    let dateAttributes = [NSAttributedString.Key.font: UIFont(name: "Helvetica Neue", size: 13),
                          NSAttributedString.Key.foregroundColor: UIColor(red: 0.6328, green: 0.6328, blue: 0.6328, alpha: 1)
                           ]
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        self.bgView.layer.cornerRadius = 20
        self.bgView.layer.borderWidth = 1
        self.bgView.layer.borderColor = UIColor.white.cgColor
        self.titleLabel.numberOfLines = 0
        self.dateLabel.numberOfLines = 0
        self.bgView.backgroundColor = .white
        self.imageV.clipsToBounds = true
        initialize()
    }
    
    func initialize()
    {
        addSubview(bgView)
        self.bgView.translatesAutoresizingMaskIntoConstraints = false
        self.imageV.translatesAutoresizingMaskIntoConstraints = false
        self.titleLabel.translatesAutoresizingMaskIntoConstraints = false
        self.dateLabel.translatesAutoresizingMaskIntoConstraints = false
        bgView.addSubview(imageV)
        bgView.addSubview(titleLabel)
        bgView.addSubview(dateLabel)
        layout()
    }
    
    func layout()
    {
        NSLayoutConstraint.activate([
            bgView.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            bgView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            bgView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            bgView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -10),
            
            titleLabel.topAnchor.constraint(equalTo: bgView.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: bgView.leadingAnchor, constant: 10),
            titleLabel.trailingAnchor.constraint(equalTo: imageV.leadingAnchor, constant: -10),
            
            dateLabel.bottomAnchor.constraint(equalTo: bgView.bottomAnchor, constant: -10),
            dateLabel.leadingAnchor.constraint(equalTo: bgView.leadingAnchor, constant: 10),
            dateLabel.trailingAnchor.constraint(equalTo: imageV.leadingAnchor, constant: -10),
            
            imageV.topAnchor.constraint(equalTo: bgView.topAnchor, constant: 0),
            imageV.trailingAnchor.constraint(equalTo: bgView.trailingAnchor, constant: 0),
            imageV.heightAnchor.constraint(equalToConstant: 150),
            imageV.widthAnchor.constraint(equalToConstant: 150),
            imageV.bottomAnchor.constraint(equalTo: bgView.bottomAnchor,constant: 0)
            ])
    }
    
    func layout1()
    {
            NSLayoutConstraint.activate([
                bgView.topAnchor.constraint(equalTo: topAnchor, constant: 10),
                bgView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
                bgView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
                bgView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -10),
                
                imageV.topAnchor.constraint(equalTo: bgView.topAnchor, constant: 0),
                imageV.trailingAnchor.constraint(equalTo: bgView.trailingAnchor, constant: 0),
                imageV.leadingAnchor.constraint(equalTo: bgView.leadingAnchor, constant: 0),
                imageV.bottomAnchor.constraint(equalTo: titleLabel.topAnchor,constant: -20),
                imageV.heightAnchor.constraint(equalToConstant: 300),
                
                titleLabel.topAnchor.constraint(equalTo: imageV.bottomAnchor, constant: 20),
                titleLabel.leadingAnchor.constraint(equalTo: bgView.leadingAnchor, constant: 10),
                titleLabel.trailingAnchor.constraint(equalTo: bgView.trailingAnchor, constant: -10),
                titleLabel.bottomAnchor.constraint(equalTo: dateLabel.topAnchor, constant: -10),

                dateLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor,constant: 10),
                dateLabel.bottomAnchor.constraint(equalTo: bgView.bottomAnchor, constant: -10),
                dateLabel.leadingAnchor.constraint(equalTo: bgView.leadingAnchor, constant: 10),
                dateLabel.trailingAnchor.constraint(equalTo: bgView.trailingAnchor, constant: -10),
            
                ])
    }
    
    func setupCell(forIndexPath indexPath: IndexPath = IndexPath(row: 0, section: 0), withObject obj: Any? = nil)
    {
        if let cObj = obj as? Images
        {
            self.titleLabel.attributedText = NSAttributedString(string: cObj.title, attributes: self.titleAttributes)
            self.dateLabel.attributedText = NSAttributedString(string: cObj.pubDate.date(format : "yyyy-MM-dd HH:mm:ss", expectedFormat: "MMM d, h:mm a"), attributes: self.dateAttributes)
            self.imageV.load(urlString: cObj.link.components(separatedBy: "?")[0])
        }
    }
}

