//
//  ViewModel.swift
//  GFG
//
//  Created by Aryan Asija on 29/01/22.
//

import Foundation
import UIKit

class GFGViewModel
{
    let urlString = "https://api.rss2json.com/v1/api.json?rss_url=http://www.abc.net.au/news/feed/51120/rss.xml"
    let session = URLSession.shared
    func callAPI(completion : @escaping (Result<Any, GFGError>) -> Void)
    {
        guard let url = URL(string: urlString) else
        {
            return
        }
        let task = session.dataTask(with: url) { data, response, error in
            if let data = data {
                do {
                    if let httpResponse = response as? HTTPURLResponse {
                        let result = self.handleNetworkResponse(response: httpResponse)
                        switch result {
                        case .success :
                            let responseObject = try JSONSerialization.jsonObject(with: data, options: .init(rawValue: 0))
                            DispatchQueue.main.async {
                                completion(.success(responseObject))
                            }
                        case .failure(let httpError):
                            DispatchQueue.main.async {
                                let error = GFGError(error: httpError)
                                completion(.failure(error))
                            }
                        }
                    }
                }
                
                catch
                {
                    DispatchQueue.main.async {
                        let error = GFGError(error: error)
                        completion(.failure(error))
                    }
                }
}
            else if let error = error {
                DispatchQueue.main.async {
                    let error = GFGError(error: error)
                    completion(.failure(error))
                }
            }
        }
        task.resume()
    }
    
    func handleNetworkResponse(response: HTTPURLResponse) -> Result<String,NetworkError> {
        
        switch response.statusCode {
        case 200...209:
            return .success("Ok")
        default:
            return .failure(NetworkError.failed)
        }
    }
}

struct GFGError: Error {
    var description = ""
    init(error:Error) {
        description = error.localizedDescription
    }
}

enum NetworkError: Error, Equatable {
case failed
    func message() -> String {
        switch self {
        case .failed:
            return "Something went wrong"
}
    }
}


class LatestImageView : UIImageView {
    
    private let imageCache = NSCache<AnyObject, UIImage>()
    var task: URLSessionDataTask?
    
    func load(urlString: String) {
        self.image = nil
        guard let url = URL(string: urlString) else
        {
            return
        }
        if let task = task
        {
            task.cancel()
        }
        
        if let imageFromCache = imageCache.object(forKey: url.absoluteString as AnyObject) as? UIImage{
            self.image = imageFromCache
            return
        }
        let session = URLSession.shared
            self.task = session.dataTask(with: url){[weak self] data, response, error in
            if data != nil
            {
                let newimage = UIImage(data: data!)
                
                if newimage != nil
                {
                    self?.imageCache.setObject(newimage!, forKey: url.absoluteString as AnyObject)
                    DispatchQueue.main.async {
                        self?.image = newimage
                }
            }
        }
        
        }
            self.task?.resume()
    }
}
extension String
{
    func date(format: String, expectedFormat: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        formatter.locale = Locale.current
        formatter.timeZone = TimeZone.current
        let date = formatter.date(from: self)
        formatter.dateFormat = expectedFormat
        return formatter.string(from: date ?? Date())
}
}
    
