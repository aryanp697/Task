//
//  GFGViewController.swift
//  GFG
//
//  Created by Aryan Asija on 29/01/22.
//

import UIKit

class GFGViewController: UIViewController {
    let viewModel = ViewModel()
    override func viewDidLoad() {
        self.navigationController?.navigationBar.isHidden = true
        self.tableView.register(UINib(nibName: "GFGTableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
        self.tableView.register(UINib(nibName: "GFG2TableViewCell", bundle: nil), forCellReuseIdentifier: "cell1")
        self.tableView.dataSource = self
        super.viewDidLoad()
        self.viewModel.GFGimages() { (status) in
            if status
            {
                self.tableView.reloadData()
            }
            else
            {
                let alert = UIAlertController(title: "Error", message: "Error Occured", preferredStyle: UIAlertController.Style.actionSheet)
                self.present(alert, animated: true, completion: nil)
                return
            }
        }
        
}
    
    @IBOutlet weak var tableView: UITableView!
}

extension GFGViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.im.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row{
        case 0:
       guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as? GFG2TableViewCell else
       {
           return UITableViewCell()
       }
        cell.setupCell(forIndexPath: indexPath, withObject: self.viewModel.im[indexPath.row])
        return cell
            
        default:
            guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? GFGTableViewCell else
            {
                return UITableViewCell()
            }
             cell.setupCell(forIndexPath: indexPath, withObject: self.viewModel.im[indexPath.row])
             return cell
        }
    }
}
