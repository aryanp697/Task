//
//  ViewModel.swift
//  GFG
//
//  Created by Aryan Asija on 29/01/22.
//

import Foundation

class ViewModel
{
    let vm = GFGViewModel()
    var im : [Images] = []
    func GFGimages(handler : @escaping (Bool) -> Void)
    {
        vm.callAPI(){ [weak self](result) in
            switch result{
        case .success(let response):
            guard let responseObj = response as? [String : Any] else
                {
                    handler(false)
                    return
                }
                guard let status = responseObj["status"] as? String, status == "ok" else
                {
                    handler(false)
                    return
                }
                guard let items = responseObj["items"] as? [[String : Any]] else
                {
                    handler(false)
                    return
                }
                for obj in items
                {
                    guard let enclosure = obj["enclosure"] as? [String : Any], let link = enclosure["link"] as? String else
                    {
                        return
                    }
                    guard let thumbnail = obj["thumbnail"] as? String else
                    {
                        return
                    }
                    guard let pubDate = obj["pubDate"] as? String else
                    {
                        return
                    }
                    guard let title = obj["title"] as? String else
                    {
                        return
                    }
                    self?.im.append(Images(thumbnail, link, title, pubDate))
                }
                handler(true)
                    
                    case .failure:
                handler(false)
        }
        
    }
    }
}

struct Images{
    var thumbnail = ""
    var link = ""
    var title = ""
    var pubDate = ""
    
    init(_ thumbnail : String, _ link : String, _ title : String, _ pubDate : String)
    {
        self.thumbnail = thumbnail
        self.link = link
        self.pubDate = pubDate
        self.title = title
    }
}
